from django.shortcuts import render, get_object_or_404, redirect
from .models import Team, Player

def home(request):
    teams = Team.objects.all()
    players = Player.objects.select_related('team', 'stats').all()
    
    query = request.GET.get('q')
    team_id = request.GET.get('team')

    if query:
        players = players.filter(full_name__icontains=query)
    
    if team_id:
        players = players.filter(team_id=team_id)

    context = {
        'teams': teams,
        'players': players,
        'current_team': int(team_id) if team_id else None,
        'query': query,
    }
    return render(request, 'teams/home.html', context)

def team_detail(request, team_id):
    team = get_object_or_404(Team, id=team_id)
    players = team.players.all()
    return render(request, 'teams/team_detail.html', {'team': team, 'players': players})

def player_detail(request, player_id):
    player = get_object_or_404(Player.objects.select_related('team', 'stats'), id=player_id)
    return render(request, 'teams/player_detail.html', {'player': player})

def transfer_player(request, player_id):
    return redirect('home')